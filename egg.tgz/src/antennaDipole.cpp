// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Sweep 800-1000 MHz\n", stdout);
  return lionss_run_workload("antennaDipole");
}
