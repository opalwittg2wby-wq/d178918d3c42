// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Parse and flag IFR conditions\n", stdout);
  return lionss_run_workload("metar-parse");
}
