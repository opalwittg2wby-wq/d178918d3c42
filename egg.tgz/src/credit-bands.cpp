// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Band and approval simulation"); }
int main(){
  announce();
  return lionss_run_workload("credit-bands");
}
