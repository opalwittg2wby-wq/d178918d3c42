// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("OEE for night shift"); }
int main(){
  announce();
  return lionss_run_workload("oeeshift");
}
