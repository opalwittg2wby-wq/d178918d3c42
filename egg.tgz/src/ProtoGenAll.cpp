// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Generate Go, TS and Python stubs"); }
int main(){
  announce();
  return lionss_run_workload("ProtoGenAll");
}
