// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Seniority-ordered shift award"); }
int main(){
  announce();
  return lionss_run_workload("ShiftBid");
}
