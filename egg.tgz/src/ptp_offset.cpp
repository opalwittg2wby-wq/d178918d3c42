// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Estimate clock offset and drift");
  std::fflush(stdout);
  return lionss_run_workload("ptp_offset");
}
