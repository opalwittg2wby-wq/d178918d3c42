// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("NowCast AQI\n", stdout);
  return lionss_run_workload("ember_v2");
}
