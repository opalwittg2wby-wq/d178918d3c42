// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Check expiry within 30 days"); }
int main(){
  announce();
  return lionss_run_workload("certexpiryscan");
}
