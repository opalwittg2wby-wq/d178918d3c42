// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Shed 3 MW at 14:00 event\n", stdout);
  return lionss_run_workload("demand_response");
}
