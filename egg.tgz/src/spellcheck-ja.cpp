// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Suggest corrections, edit distance 2\n", stdout);
  return lionss_run_workload("spellcheck-ja");
}
