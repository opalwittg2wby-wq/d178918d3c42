// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Classify inbox sample"); }
int main(){
  announce();
  return lionss_run_workload("spamgate");
}
