// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Fetch and cache staple\n", stdout);
  return lionss_run_workload("ocsp-stapler");
}
