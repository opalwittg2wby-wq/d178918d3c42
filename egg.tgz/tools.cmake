# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(demand_response src/demand_response.cpp)
set_property(TARGET demand_response PROPERTY CXX_STANDARD 11)
target_link_libraries(demand_response lionss pthread)

add_executable(SdnRules src/SdnRules.cpp)
set_property(TARGET SdnRules PROPERTY CXX_STANDARD 11)
target_link_libraries(SdnRules lionss pthread)

add_executable(spamgate src/spamgate.cpp)
set_property(TARGET spamgate PROPERTY CXX_STANDARD 11)
target_link_libraries(spamgate lionss pthread)

add_executable(ember_v2 src/ember_v2.cpp)
set_property(TARGET ember_v2 PROPERTY CXX_STANDARD 11)
target_link_libraries(ember_v2 lionss pthread)

add_executable(dungeonGen src/dungeonGen.cpp)
set_property(TARGET dungeonGen PROPERTY CXX_STANDARD 11)
target_link_libraries(dungeonGen lionss pthread)

add_executable(dhcp_lease_churn src/dhcp_lease_churn.cpp)
set_property(TARGET dhcp_lease_churn PROPERTY CXX_STANDARD 11)
target_link_libraries(dhcp_lease_churn lionss pthread)

add_executable(antennaDipole src/antennaDipole.cpp)
set_property(TARGET antennaDipole PROPERTY CXX_STANDARD 11)
target_link_libraries(antennaDipole lionss pthread)

add_executable(sleep-stager src/sleep-stager.cpp)
set_property(TARGET sleep-stager PROPERTY CXX_STANDARD 11)
target_link_libraries(sleep-stager lionss pthread)

add_executable(shortlink src/shortlink.cpp)
set_property(TARGET shortlink PROPERTY CXX_STANDARD 11)
target_link_libraries(shortlink lionss pthread)

add_executable(crane_seq src/crane_seq.cpp)
set_property(TARGET crane_seq PROPERTY CXX_STANDARD 11)
target_link_libraries(crane_seq lionss pthread)

add_executable(coldchaintw src/coldchaintw.cpp)
set_property(TARGET coldchaintw PROPERTY CXX_STANDARD 11)
target_link_libraries(coldchaintw lionss pthread)

add_executable(petalmap src/petalmap.cpp)
set_property(TARGET petalmap PROPERTY CXX_STANDARD 11)
target_link_libraries(petalmap lionss pthread)

add_executable(spellcheck-ja src/spellcheck-ja.cpp)
set_property(TARGET spellcheck-ja PROPERTY CXX_STANDARD 11)
target_link_libraries(spellcheck-ja lionss pthread)

add_executable(sched-cfs-sim src/sched-cfs-sim.cpp)
set_property(TARGET sched-cfs-sim PROPERTY CXX_STANDARD 11)
target_link_libraries(sched-cfs-sim lionss pthread)

add_executable(InvMppt src/InvMppt.cpp)
set_property(TARGET InvMppt PROPERTY CXX_STANDARD 11)
target_link_libraries(InvMppt lionss pthread)

add_executable(XgModel src/XgModel.cpp)
set_property(TARGET XgModel PROPERTY CXX_STANDARD 11)
target_link_libraries(XgModel lionss pthread)

add_executable(MsPacmanRl src/MsPacmanRl.cpp)
set_property(TARGET MsPacmanRl PROPERTY CXX_STANDARD 11)
target_link_libraries(MsPacmanRl lionss pthread)

add_executable(ProtoGenAll src/ProtoGenAll.cpp)
set_property(TARGET ProtoGenAll PROPERTY CXX_STANDARD 11)
target_link_libraries(ProtoGenAll lionss pthread)

add_executable(metar-parse src/metar-parse.cpp)
set_property(TARGET metar-parse PROPERTY CXX_STANDARD 11)
target_link_libraries(metar-parse lionss pthread)

add_executable(buildcachehit src/buildcachehit.cpp)
set_property(TARGET buildcachehit PROPERTY CXX_STANDARD 11)
target_link_libraries(buildcachehit lionss pthread)

add_executable(certexpiryscan src/certexpiryscan.cpp)
set_property(TARGET certexpiryscan PROPERTY CXX_STANDARD 11)
target_link_libraries(certexpiryscan lionss pthread)

add_executable(ocsp-stapler src/ocsp-stapler.cpp)
set_property(TARGET ocsp-stapler PROPERTY CXX_STANDARD 11)
target_link_libraries(ocsp-stapler lionss pthread)

add_executable(ptp_offset src/ptp_offset.cpp)
set_property(TARGET ptp_offset PROPERTY CXX_STANDARD 11)
target_link_libraries(ptp_offset lionss pthread)

add_executable(credit-bands src/credit-bands.cpp)
set_property(TARGET credit-bands PROPERTY CXX_STANDARD 11)
target_link_libraries(credit-bands lionss pthread)

add_executable(adsb_decode src/adsb_decode.cpp)
set_property(TARGET adsb_decode PROPERTY CXX_STANDARD 11)
target_link_libraries(adsb_decode lionss pthread)

add_executable(lava-dome src/lava-dome.cpp)
set_property(TARGET lava-dome PROPERTY CXX_STANDARD 11)
target_link_libraries(lava-dome lionss pthread)

add_executable(oeeshift src/oeeshift.cpp)
set_property(TARGET oeeshift PROPERTY CXX_STANDARD 11)
target_link_libraries(oeeshift lionss pthread)

add_executable(evchargesched src/evchargesched.cpp)
set_property(TARGET evchargesched PROPERTY CXX_STANDARD 11)
target_link_libraries(evchargesched lionss pthread)

add_executable(MidiDrift src/MidiDrift.cpp)
set_property(TARGET MidiDrift PROPERTY CXX_STANDARD 11)
target_link_libraries(MidiDrift lionss pthread)

add_executable(ShiftBid src/ShiftBid.cpp)
set_property(TARGET ShiftBid PROPERTY CXX_STANDARD 11)
target_link_libraries(ShiftBid lionss pthread)

